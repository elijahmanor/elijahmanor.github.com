# Temperamental Timers

------

setInterval vs setTimeout
