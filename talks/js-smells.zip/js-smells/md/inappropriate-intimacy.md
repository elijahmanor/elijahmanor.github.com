# Inappropriate Intimacy

------

## (a class that has dependencies on implementation details of another class)

------
