# Pig Latin

1. <!-- .element start="1" value="1" --> If starts with consonant (or consonant cluster), then move the end and append "ay" <!-- .element class="fragment" -->

```
"pig"    -> "igpay"
"banana" -> "ananabay"
"trash"  -> "ashtray"
"happy"  -> "appyhay"
"glove"  -> "oveglay"
```
<!-- .element class="fragment" -->

2. <!-- .element start="2" value="2" --> If starts with vowel or silent letter, then keep word along and append "way" <!-- .element class="fragment" -->

```
"egg"    -> "eggway"
"inbox"  -> "inboxway"
"eight"  -> "eightway"
```
<!-- .element class="fragment" -->
