# Promise Proliferation

------

http://taoofcode.net/promise-anti-patterns/
https://github.com/petkaantonov/bluebird/wiki/Promise-anti-patterns#the-deferred-anti-pattern
