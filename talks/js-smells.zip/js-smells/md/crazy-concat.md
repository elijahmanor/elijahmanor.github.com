# String Concatenation

------

## Think of a better name...

```
// Thanks Damon ;)
$( "<div id='tab'><a href='' id='"+ myId +""'></div>" );
```
