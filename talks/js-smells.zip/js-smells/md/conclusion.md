# Questions?

<pre style="font-size: 1.25em; box-shadow: none;">
<a href="http://elijahmanor.com]" class="fragment" style="margin-left: 2em;">http://elijahmanor.com</a>
<a href="http://twitter.com/elijahmanor" class="fragment" style="margin-left: 5.5em;">@elijahmanor</a>
<a href="mailto:elijahmanor@gmail.com" class="fragment" style="position: absolute; left: 6.1em;">elijahmanor@gmail.com</a>
</pre>

<pre style="font-size: 1.25em; box-shadow: none;">
<a href="http://bit.ly/good-js-libs" class="fragment" style="margin-left: 2em;">http://bit.ly/good-js-libs</a>
</pre>

### @nomadjs / #nomadjs

------

* Problem: $paghetti Code, Solution:

* Passing data all way down (), Solution:

* Problem: add/remove code

------

```
if (flag) {  
  node.addClass('someClass');
} else {
  node.removeClass('someClass');
}
```

```
node.toggleClass('someClass', flag);
```

```
test && doThis();
```

------

# Tips, Tricks, & Techniques

# ESLint Custom Rules

Notes:

# SrcByLine

<pre><code data-trim data-lang="javascript" data-srcbyline="js/intro.js?1-4;10;19-20;31-33"></code></pre>

<pre><code data-trim contenteditable>console.log('code');</code></pre>
