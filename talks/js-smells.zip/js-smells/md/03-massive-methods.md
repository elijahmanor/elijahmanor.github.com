# Smelly Code

```
```

------

# Massive Methods!

* Too Many Statements <!-- .element class="fragment" -->
* Too Many Parameters <!-- .element class="fragment" -->
* Too Much Depth <!-- .element class="fragment" -->

------

```
/* jshint maxparams:3, maxdepth:2, maxstatements:5 */
```
