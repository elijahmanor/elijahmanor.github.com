# Incessant Interactions

------

(debounce, throttle)

window resize, scroll, autocomplete (typing)

profiler
9anonymous function
