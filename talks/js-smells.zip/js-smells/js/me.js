{
  "priorities" : [ "Christian", "Family", "Work" ],
  "work"       : [ "@DaveRamsey", "@PluralSight" ],
  "tech"       : [ "HTML", "CSS", "JavaScript", "React", "jQuery" ],
  "titles"     : [ "MS MVP", "IE userAgent" ]
}
