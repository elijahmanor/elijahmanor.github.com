if (true) {
  alert('hello');
}

while (true) {
  console.log('what is this?');
}

if (true) {
  alert('hello');
}

while (true) {
  console.log('what is this?');
}

if (true) {
  alert('hello');
}

while (true) {
  console.log('what is this?');
}

if (true) {
  alert('hello');
}

while (true) {
  console.log('what is this?');
}
if (true) {
  alert('hello');
}

while (true) {
  console.log('what is this?');
}

if (true) {
  alert('hello');
}

while (true) {
  console.log('what is this?');
}
