var presentationConfig = {
	"dependencies": [
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		},
		{
			"enabled": false
		}
	]
};