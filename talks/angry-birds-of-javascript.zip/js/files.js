var presentationFiles = [
	{
		"_id": "528bfef6f4bc71c258000009",
		"updatedAt": "2013-12-20T20:13:56.789Z",
		"url": "",
		"content": "```javascript\nvar type = \"Red\",\n    attack = function() {\n        var secret = oops = \"shh\";\n\n        typeOfBird = type + \" Bird\";\n        console.log( typeOfBird + \" Bird Attacks!\" );\n    };\n\nconsole.log( window.type );       // I'm a global variable\nwindow.attack();                  // I'm a global function\nconsole.log( window.typeOfBird ); // I'm a global variable too :(\nconsole.log( window.oops );       // I'm a global variable too :(\n```",
		"mimeType": "text/plain",
		"language": "",
		"folder": false,
		"parent": null,
		"name": "global"
	},
	{
		"_id": "528bff4b0b1616bf58000007",
		"updatedAt": "2013-12-20T20:13:56.789Z",
		"url": "",
		"content": "var type = \"Red\",\n    attack = function() {\n        var private = oops = \"secret\";\n\n        typeOfBird = type + \" Bird\";\n        window.message = typeOfBird + \" Attacks!\";\n        console.log( birdType + \" Bird Attacks!\" );\n    };\n\nconsole.log( window.type );       // I'm a global variable\nwindow.attack();                  // I'm a global function\nconsole.log( window.typeOfBird ); // I'm a global variable too :(\nconsole.log( window.oops );       // I'm a global variable too :(\nconsole.log( window.message );    // I'm a global variable too :|",
		"mimeType": "text/plain",
		"language": "text/javascript",
		"folder": false,
		"parent": null,
		"name": "global.js"
	}
];