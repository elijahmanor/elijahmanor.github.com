(function( app, $ ){

}( window.notesapp = window.notesapp || {}, jQuery ));