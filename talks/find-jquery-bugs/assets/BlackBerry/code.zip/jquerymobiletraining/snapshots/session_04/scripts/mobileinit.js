(function( $ ){

$( document ).on( "mobileinit", function () {

	$.mobile.pushStateEnabled = false;
	$.mobile.defaultPageTransition = "none";

});

}( jQuery ));